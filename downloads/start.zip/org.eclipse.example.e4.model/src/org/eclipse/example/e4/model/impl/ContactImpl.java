/**
 */
package org.eclipse.example.e4.model.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.example.e4.model.Contact;
import org.eclipse.example.e4.model.ModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Contact</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ContactImpl extends ContactEntryImpl implements Contact {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContactImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelPackage.Literals.CONTACT;
	}

} //ContactImpl

package org.eclipse.example.e4.handlers;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.example.e4.model.Contact;
import org.eclipse.example.e4.model.ContactService;
import org.eclipse.example.e4.model.ModelFactory;
import org.eclipse.example.e4.parts.DetailsView;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

public class NewContactHandler {

	@Execute
	void execute(Shell shell, ContactService service) {
		final Contact newContact = ModelFactory.eINSTANCE.createContact();
		TitleAreaDialog dialog = new TitleAreaDialog(shell) {

			private DetailsView detailsView;

			@Override
			protected Control createDialogArea(Composite parent) {
				setTitle("Create New Contact");
				setMessage("Enter new contact's details");
				detailsView = new DetailsView(parent);
				detailsView.setInput(newContact);
				
				return parent;
			}

			@Override
			protected void okPressed() {
				detailsView.save();
				super.okPressed();
			}
		};
		if (dialog.open() == Dialog.OK) {
			service.addContact(newContact);
		}
	}
}
package org.eclipse.example.e4;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.inject.Inject;

import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.workbench.modeling.ESelectionService;
import org.eclipse.example.e4.model.ContactService;
import org.eclipse.example.e4.model.provider.SWTExampleHelper;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
@SuppressWarnings("restriction")

public class ContactsView {

	@Inject
	ContactService contactService;
	
	@Inject
	ESelectionService selectionService;
	
	private TreeViewer treeViewer;

	@Inject
	public ContactsView(Composite parent) {
		treeViewer = SWTExampleHelper.createTreeViewer(parent);
	}

	@PostConstruct
	public void init() {
		treeViewer.setInput(contactService.getInput());
		SWTExampleHelper.connectTreeViewerWithSelectionService(treeViewer, selectionService);
	}
	
	@Focus
	public void setFocus(){
		treeViewer.getTree().setFocus();
	}
	
	@PreDestroy
	public void dispose(){
		SWTExampleHelper.dispose(treeViewer);
	}
	
}

package org.eclipse.example.e4;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.e4.core.di.annotations.Optional;
import org.eclipse.e4.ui.di.Persist;
import org.eclipse.e4.ui.model.application.ui.MDirtyable;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.example.e4.model.ContactEntry;
import org.eclipse.example.e4.model.provider.SWTExampleHelper;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

@SuppressWarnings("restriction")
public class DetailsView {

	@Inject
	MDirtyable dirtyable;

	private Text text;

	private ContactEntry input;

	@Inject
	public DetailsView(Composite parent) {
		text = SWTExampleHelper.createTextWithLabel(parent);
	}

	@PostConstruct
	public void init() {
		text.addModifyListener(new ModifyListener() {

			@Override
			public void modifyText(ModifyEvent e) {
				dirtyable.setDirty(true);

			}
		});
	}

	@Persist
	public void save() {
		input.setName(text.getText());
		dirtyable.setDirty(false);
	}

	@Inject
	public void setInput(
			@Optional @Named(IServiceConstants.ACTIVE_SELECTION) ContactEntry contactEntry) {
		if (contactEntry == null) {
			text.setText("");
			input = null;
		} else {
			text.setText(contactEntry.getName());
			input = contactEntry;
		}
		dirtyable.setDirty(false);
	}

}

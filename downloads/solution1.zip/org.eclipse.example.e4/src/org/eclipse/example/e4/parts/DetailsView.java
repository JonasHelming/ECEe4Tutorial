package org.eclipse.example.e4.parts;

import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.e4.core.di.annotations.Optional;
import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.di.Persist;
import org.eclipse.e4.ui.model.application.ui.MDirtyable;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.example.e4.model.ContactEntry;
import org.eclipse.example.e4.model.provider.SWTExampleHelper;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;

public class DetailsView {


	Text text;

	ContactEntry entry;

	@Inject
	public DetailsView(Composite parent) {
		text = SWTExampleHelper.createTextWithLabel(parent);
	}


	@Inject
	@Optional
	public void setInput(
			@Named(IServiceConstants.ACTIVE_SELECTION) ContactEntry entry) {
		this.entry = entry;
		String newValue = (entry == null || entry.getName() == null) ? "" : entry
				.getName();
		text.setText(newValue);
	}

	@Focus
	public void setFocus() {
		text.setFocus();
	}

	

}

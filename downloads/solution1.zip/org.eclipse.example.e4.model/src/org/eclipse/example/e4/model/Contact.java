/**
 */
package org.eclipse.example.e4.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Contact</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.example.e4.model.ModelPackage#getContact()
 * @model
 * @generated
 */
public interface Contact extends ContactEntry {
} // Contact
